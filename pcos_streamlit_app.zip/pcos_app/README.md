# PCOS Detection – Streamlit dashboard

## Files
- `app.py` – the whole app (pipeline + dashboard) in one file
- `requirements.txt` – dependencies
- `.streamlit/config.toml` – dark theme
- `data/` – put `PCOS_data_without_infertility.xlsx` here (or upload it from the sidebar)

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```
Main file for deployment: `app.py`.
